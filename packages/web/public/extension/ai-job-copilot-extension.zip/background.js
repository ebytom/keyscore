// AI Job Copilot - Background Service Worker

const API_BASE_URL = 'http://localhost:4000/api';

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then(sendResponse);
  return true; // Keep message channel open for async response
});

async function handleMessage(message, sender) {
  switch (message.type) {
    case 'GET_AUTH_STATUS':
      return await getAuthStatus();
    case 'GET_RESUMES':
      return await getResumes();
    case 'ANALYZE_JD':
      return await analyzeJD(message.data);
    case 'COMPARE_RESUME':
      return await compareResumeWithJD(message.data);
    default:
      return { success: false, error: 'Unknown message type' };
  }
}

// Get stored auth token
async function getAuthToken() {
  const result = await chrome.storage.local.get(['accessToken']);
  return result.accessToken;
}

// Check authentication status
async function getAuthStatus() {
  const token = await getAuthToken();
  if (!token) {
    return { isAuthenticated: false };
  }

  try {
    const response = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (response.ok) {
      const data = await response.json();
      return { isAuthenticated: true, user: data.user };
    } else {
      await chrome.storage.local.remove(['accessToken', 'refreshToken', 'user']);
      return { isAuthenticated: false };
    }
  } catch (error) {
    console.error('Auth check failed:', error);
    return { isAuthenticated: false, error: error.message };
  }
}

// Get user's resumes
async function getResumes() {
  const token = await getAuthToken();
  if (!token) {
    return { success: false, error: 'Not authenticated' };
  }

  try {
    const response = await fetch(`${API_BASE_URL}/resumes`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const data = await response.json();

    if (response.ok) {
      return { success: true, data: data.data };
    } else {
      return { success: false, error: data.message };
    }
  } catch (error) {
    console.error('Get resumes failed:', error);
    return { success: false, error: error.message };
  }
}

// Analyze JD and compare with all resumes
async function analyzeJD(jobDescription) {
  const token = await getAuthToken();
  if (!token) {
    return { success: false, error: 'Not authenticated' };
  }

  try {
    const response = await fetch(`${API_BASE_URL}/ai/analyze-jd`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ jobDescription }),
    });

    const data = await response.json();

    if (response.ok) {
      return { success: true, data: data.data };
    } else {
      return { success: false, error: data.message };
    }
  } catch (error) {
    console.error('Analyze JD failed:', error);
    return { success: false, error: error.message };
  }
}

// Compare a specific resume with JD
async function compareResumeWithJD({ resumeId, jobDescription }) {
  const token = await getAuthToken();
  if (!token) {
    return { success: false, error: 'Not authenticated' };
  }

  try {
    const response = await fetch(`${API_BASE_URL}/ai/compare`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({ resumeId, jobDescription }),
    });

    const data = await response.json();

    if (response.ok) {
      return { success: true, data: data.data };
    } else {
      return { success: false, error: data.message };
    }
  } catch (error) {
    console.error('Compare failed:', error);
    return { success: false, error: error.message };
  }
}
