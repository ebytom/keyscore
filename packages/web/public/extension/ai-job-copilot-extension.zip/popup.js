// AI Job Copilot - Popup Script

const API_URL = 'http://localhost:4000/api';
const APP_URL = 'http://localhost:3000';

// DOM Elements
const loadingState = document.getElementById('loadingState');
const authSection = document.getElementById('authSection');
const mainContent = document.getElementById('mainContent');
const userAvatar = document.getElementById('userAvatar');
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const statusMessage = document.getElementById('statusMessage');
const jdStatus = document.getElementById('jdStatus');
const jdStatusText = document.getElementById('jdStatusText');
const jdPreview = document.getElementById('jdPreview');
const extractJdBtn = document.getElementById('extractJdBtn');
const analyzeBtn = document.getElementById('analyzeBtn');
const resumesSection = document.getElementById('resumesSection');
const resumeList = document.getElementById('resumeList');
const noResumes = document.getElementById('noResumes');
const detailView = document.getElementById('detailView');
const backBtn = document.getElementById('backBtn');
const detailTitle = document.getElementById('detailTitle');
const detailScoreValue = document.getElementById('detailScoreValue');
const matchedKeywords = document.getElementById('matchedKeywords');
const missingKeywords = document.getElementById('missingKeywords');
const matchedCount = document.getElementById('matchedCount');
const missingCount = document.getElementById('missingCount');

// State
let isAuthenticated = false;
let currentUser = null;
let resumes = [];
let currentJD = null;
let analysisResults = null;

// Initialize
document.addEventListener('DOMContentLoaded', init);

async function init() {
  console.log('AI Job Copilot: Popup initialized');

  try {
    await checkPendingAuth();
    await checkAuthStatus();

    if (isAuthenticated) {
      await loadResumes();
    }
  } catch (error) {
    console.error('Init error:', error);
    // Show auth section as fallback
    showAuthSection();
  }
}

// Check for pending auth from web app
async function checkPendingAuth() {
  console.log('Checking pending auth...');
  try {
    const tabs = await chrome.tabs.query({ url: `${APP_URL}/*` });
    console.log('Found tabs:', tabs.length);

    for (const tab of tabs) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const authData = localStorage.getItem('extension-auth');
            if (authData) {
              localStorage.removeItem('extension-auth');
              return JSON.parse(authData);
            }
            return null;
          },
        });

        const authData = results?.[0]?.result;
        if (authData?.accessToken) {
          console.log('Found auth data from web app');
          await chrome.storage.local.set({
            accessToken: authData.accessToken,
            refreshToken: authData.refreshToken,
            user: authData.user,
          });
          break;
        }
      } catch (e) {
        console.log('Could not access tab:', e.message);
      }
    }
  } catch (error) {
    console.log('Error checking pending auth:', error.message);
  }
}

// Check auth status
async function checkAuthStatus() {
  console.log('Checking auth status...');
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_AUTH_STATUS' });
    console.log('Auth response:', response);

    if (response?.isAuthenticated) {
      isAuthenticated = true;
      currentUser = response.user;
      showMainContent();
    } else {
      showAuthSection();
    }
  } catch (error) {
    console.error('Auth check error:', error);
    showAuthSection();
  }
}

// Show auth section
function showAuthSection() {
  loadingState.classList.add('hidden');
  authSection.classList.remove('hidden');
  mainContent.classList.add('hidden');
  userAvatar.classList.add('hidden');
  logoutBtn.classList.add('hidden');
}

// Show main content
function showMainContent() {
  loadingState.classList.add('hidden');
  authSection.classList.add('hidden');
  mainContent.classList.remove('hidden');

  if (currentUser) {
    const initials = (currentUser.firstName?.[0] || '') + (currentUser.lastName?.[0] || '');
    userAvatar.textContent = initials.toUpperCase() || 'U';
    userAvatar.classList.remove('hidden');
    logoutBtn.classList.remove('hidden');
  }
}

// Load user's resumes
async function loadResumes() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_RESUMES' });
    if (response.success && response.data) {
      resumes = response.data;
      renderResumes();
    } else {
      showNoResumes();
    }
  } catch (error) {
    console.error('Failed to load resumes:', error);
    showStatus('Failed to load resumes', 'error');
  }
}

// Render resumes list
function renderResumes() {
  if (resumes.length === 0) {
    showNoResumes();
    return;
  }

  resumesSection.classList.remove('hidden');
  noResumes.classList.add('hidden');

  resumeList.innerHTML = resumes.map((resume, index) => {
    const analysis = analysisResults?.find(r => r.resumeId === resume._id);
    const score = analysis?.score;
    const scoreClass = score >= 80 ? 'high' : score >= 60 ? 'medium' : 'low';
    const isBestMatch = analysisResults && index === 0 && score >= 70;

    return `
      <div class="resume-card ${isBestMatch ? 'best-match' : ''}" data-id="${resume._id}">
        <div class="resume-header">
          <div class="resume-info">
            <div class="resume-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
            </div>
            <div>
              <div class="resume-name">${resume.name}</div>
              <div class="resume-meta">${formatFileSize(resume.size)} • ${resume.isDefault ? '⭐ Primary' : 'Updated ' + formatDate(resume.updatedAt)}</div>
            </div>
          </div>
          ${score !== undefined ? `
            <div class="resume-score">
              <span class="score-value ${scoreClass}">${score}%</span>
              <span class="score-label">Match</span>
            </div>
          ` : ''}
        </div>
        ${isBestMatch ? `
          <div class="best-match-badge">
            <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
            </svg>
            Best Match
          </div>
        ` : ''}
        ${analysis ? `
          <div class="keywords-preview">
            <div class="keywords-row">
              <span class="keywords-label">Matched:</span>
              <div class="keywords-tags">
                ${analysis.matchedKeywords.slice(0, 4).map(k => `
                  <span class="keyword-tag matched">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    ${k}
                  </span>
                `).join('')}
                ${analysis.matchedKeywords.length > 4 ? `<span class="keyword-tag matched">+${analysis.matchedKeywords.length - 4}</span>` : ''}
              </div>
            </div>
            <div class="keywords-row">
              <span class="keywords-label">Missing:</span>
              <div class="keywords-tags">
                ${analysis.missingKeywords.slice(0, 4).map(k => `
                  <span class="keyword-tag missing">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                    ${k}
                  </span>
                `).join('')}
                ${analysis.missingKeywords.length > 4 ? `<span class="keyword-tag missing">+${analysis.missingKeywords.length - 4}</span>` : ''}
              </div>
            </div>
          </div>
        ` : ''}
      </div>
    `;
  }).join('');

  // Add click handlers
  document.querySelectorAll('.resume-card').forEach(card => {
    card.addEventListener('click', () => showResumeDetail(card.dataset.id));
  });
}

// Show no resumes state
function showNoResumes() {
  resumesSection.classList.add('hidden');
  noResumes.classList.remove('hidden');
}

// Extract JD from current page
async function extractJD() {
  extractJdBtn.disabled = true;
  extractJdBtn.innerHTML = `
    <svg class="spinner" width="14" height="14" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" opacity="0.25"/>
      <path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
    </svg>
    Extracting...
  `;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id) {
      throw new Error('No active tab');
    }

    // Inject and execute JD extraction script
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractJobDescription,
    });

    const jdText = results?.[0]?.result;

    if (jdText && jdText.length > 50) {
      currentJD = jdText;
      jdPreview.textContent = jdText.substring(0, 200) + '...';
      jdStatus.classList.remove('hidden');
      jdStatusText.textContent = `Detected (${jdText.length} chars)`;
      analyzeBtn.classList.remove('hidden');
      showStatus('Job description extracted successfully!', 'success');
    } else {
      throw new Error('Could not find job description on this page');
    }
  } catch (error) {
    console.error('JD extraction error:', error);
    jdStatus.classList.remove('hidden');
    jdStatus.classList.add('error');
    jdStatusText.textContent = 'Not found';
    showStatus(error.message || 'Failed to extract JD', 'error');
  } finally {
    extractJdBtn.disabled = false;
    extractJdBtn.innerHTML = `
      <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
      </svg>
      Extract JD
    `;
  }
}

// JD extraction function (runs in page context)
function extractJobDescription() {
  // Helper to clean text
  const cleanText = (text) => {
    return text
      .replace(/\s+/g, ' ')
      .replace(/\n\s*\n/g, '\n')
      .trim();
  };

  // LinkedIn-specific extraction
  if (window.location.hostname.includes('linkedin.com')) {
    // Try the job details panel (right side)
    const jobDetailsSelectors = [
      '.jobs-description__content',
      '.jobs-description-content__text',
      '.jobs-box__html-content',
      '[class*="jobs-description"]',
      '.job-view-layout .description',
    ];

    for (const selector of jobDetailsSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        const text = cleanText(el.innerText);
        if (text.length > 100) return text;
      }
    }

    // Try to find "About the job" section specifically
    const aboutJobHeader = Array.from(document.querySelectorAll('h2, h3, .jobs-description h2')).find(
      h => h.innerText?.toLowerCase().includes('about the job') ||
           h.innerText?.toLowerCase().includes('about this job')
    );
    if (aboutJobHeader) {
      // Get the parent container or next sibling with content
      let container = aboutJobHeader.closest('section') ||
                      aboutJobHeader.closest('[class*="description"]') ||
                      aboutJobHeader.parentElement;
      if (container) {
        const text = cleanText(container.innerText);
        if (text.length > 100) return text;
      }
    }

    // Fallback: find the main job content area (right panel)
    const rightPanel = document.querySelector('.jobs-search__job-details, .job-view-layout, .jobs-details');
    if (rightPanel) {
      // Exclude the header/apply button area, focus on description
      const descArea = rightPanel.querySelector('[class*="description"]') || rightPanel;
      const text = cleanText(descArea.innerText);
      // Limit to reasonable length and try to cut at a good point
      if (text.length > 200) {
        // Find where the actual job content starts (skip company/title header)
        const aboutIndex = text.toLowerCase().indexOf('about');
        if (aboutIndex > 0 && aboutIndex < 500) {
          return text.substring(aboutIndex);
        }
        return text.substring(0, 5000);
      }
    }
  }

  // Indeed-specific extraction
  if (window.location.hostname.includes('indeed.com')) {
    const indeedSelectors = [
      '#jobDescriptionText',
      '.jobsearch-jobDescriptionText',
      '[class*="jobDescription"]',
    ];
    for (const selector of indeedSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        const text = cleanText(el.innerText);
        if (text.length > 100) return text;
      }
    }
  }

  // Greenhouse-specific
  if (window.location.hostname.includes('greenhouse.io')) {
    const el = document.querySelector('#content .content, .content-wrapper, [class*="job-post"]');
    if (el) return cleanText(el.innerText);
  }

  // Lever-specific
  if (window.location.hostname.includes('lever.co')) {
    const el = document.querySelector('.posting-page, [class*="posting"]');
    if (el) return cleanText(el.innerText);
  }

  // Workday-specific
  if (window.location.hostname.includes('workday.com') || window.location.hostname.includes('myworkdayjobs.com')) {
    const el = document.querySelector('[data-automation-id="jobPostingDescription"], [class*="jobDescription"]');
    if (el) return cleanText(el.innerText);
  }

  // Generic job site selectors
  const genericSelectors = [
    '[class*="job-description"]',
    '[class*="jobDescription"]',
    '[class*="job_description"]',
    '[id*="job-description"]',
    '[id*="jobDescription"]',
    '[data-testid*="description"]',
    '.description',
    '#description',
    'article[class*="job"]',
    '.posting-requirements',
    '.job-details',
  ];

  for (const selector of genericSelectors) {
    const el = document.querySelector(selector);
    if (el) {
      const text = cleanText(el.innerText);
      if (text.length > 100 && text.length < 15000) {
        return text;
      }
    }
  }

  // Last resort: find the largest reasonable text block that looks like a JD
  const candidates = document.querySelectorAll('div, section, article');
  let bestMatch = null;
  let bestScore = 0;

  const jdKeywords = ['responsibilities', 'requirements', 'qualifications', 'experience', 'skills', 'about the job', 'job description', 'what you', 'who you'];

  candidates.forEach(el => {
    const text = el.innerText || '';
    const len = text.length;

    // Skip if too short or too long
    if (len < 200 || len > 20000) return;

    // Score based on JD-related keywords
    let score = 0;
    const lowerText = text.toLowerCase();
    jdKeywords.forEach(kw => {
      if (lowerText.includes(kw)) score += 10;
    });

    // Prefer medium-length content
    if (len > 500 && len < 5000) score += 5;

    // Penalize if it contains too many links (navigation)
    const linkCount = el.querySelectorAll('a').length;
    if (linkCount > 20) score -= 10;

    if (score > bestScore) {
      bestScore = score;
      bestMatch = text;
    }
  });

  if (bestMatch && bestScore >= 10) {
    return cleanText(bestMatch);
  }

  return null;
}

// Analyze all resumes against JD
async function analyzeAllResumes() {
  if (!currentJD) {
    showStatus('Please extract a job description first', 'error');
    return;
  }

  analyzeBtn.disabled = true;
  analyzeBtn.innerHTML = `
    <svg class="spinner" width="14" height="14" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" opacity="0.25"/>
      <path fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
    </svg>
    Analyzing...
  `;

  try {
    // For now, simulate analysis (TODO: connect to AI backend)
    analysisResults = await simulateAnalysis(resumes, currentJD);

    // Sort by score
    analysisResults.sort((a, b) => b.score - a.score);

    // Re-order resumes by score
    resumes.sort((a, b) => {
      const scoreA = analysisResults.find(r => r.resumeId === a._id)?.score || 0;
      const scoreB = analysisResults.find(r => r.resumeId === b._id)?.score || 0;
      return scoreB - scoreA;
    });

    renderResumes();
    showStatus('Analysis complete!', 'success');
  } catch (error) {
    console.error('Analysis error:', error);
    showStatus('Analysis failed. Please try again.', 'error');
  } finally {
    analyzeBtn.disabled = false;
    analyzeBtn.innerHTML = `
      <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
      </svg>
      Analyze All Resumes
    `;
  }
}

// Simulate analysis (TODO: replace with real API call when resume parsing is implemented)
async function simulateAnalysis(resumes, jd) {
  // Extract keywords from JD
  const keywords = extractKeywordsFromJD(jd);

  console.log('Extracted keywords:', keywords);

  return resumes.map(resume => {
    // For now, since resumes aren't parsed yet, we'll simulate based on resume name
    // In production, this would compare against resume.parsedContent
    const resumeText = (
      resume.name + ' ' +
      resume.filename + ' ' +
      (resume.parsedContent?.skills?.join(' ') || '') +
      (resume.parsedContent?.fullText || '')
    ).toLowerCase();

    const matchedKeywords = [];
    const missingKeywords = [];

    keywords.forEach(kw => {
      if (resumeText.includes(kw.toLowerCase())) {
        matchedKeywords.push(kw);
      } else {
        missingKeywords.push(kw);
      }
    });

    // Calculate score - if no parsed content, give a base score + some randomness
    let score;
    if (matchedKeywords.length > 0) {
      score = Math.round((matchedKeywords.length / keywords.length) * 100);
    } else {
      // No parsed content yet - show estimated score
      score = Math.floor(Math.random() * 25 + 45); // 45-70% range
    }

    return {
      resumeId: resume._id,
      score,
      matchedKeywords,
      missingKeywords,
      keywords,
      hasParsedContent: !!(resume.parsedContent?.fullText || resume.parsedContent?.skills?.length),
    };
  });
}

// Extract keywords from JD text
function extractKeywordsFromJD(jdText) {
  const text = jdText.toLowerCase();

  // Technical skills to look for
  const technicalKeywords = [
    // Programming Languages
    'javascript', 'typescript', 'python', 'java', 'c++', 'c#', 'go', 'golang', 'rust', 'ruby', 'php', 'swift', 'kotlin', 'scala',
    // Frontend
    'react', 'reactjs', 'react.js', 'angular', 'vue', 'vuejs', 'vue.js', 'next.js', 'nextjs', 'svelte', 'html', 'css', 'sass', 'tailwind', 'bootstrap',
    // Backend
    'node.js', 'nodejs', 'node', 'express', 'expressjs', 'django', 'flask', 'fastapi', 'spring', 'spring boot', 'rails', 'ruby on rails', '.net', 'asp.net',
    // Databases
    'postgresql', 'postgres', 'mysql', 'mongodb', 'redis', 'elasticsearch', 'dynamodb', 'cassandra', 'sql', 'nosql', 'oracle', 'sqlite',
    // Cloud & DevOps
    'aws', 'amazon web services', 'azure', 'gcp', 'google cloud', 'docker', 'kubernetes', 'k8s', 'terraform', 'jenkins', 'ci/cd', 'github actions', 'gitlab',
    // APIs & Architecture
    'rest', 'restful', 'graphql', 'grpc', 'microservices', 'api', 'apis', 'websocket', 'oauth', 'jwt',
    // Data & AI
    'machine learning', 'ml', 'ai', 'artificial intelligence', 'deep learning', 'tensorflow', 'pytorch', 'data science', 'nlp', 'computer vision',
    // Tools & Practices
    'git', 'agile', 'scrum', 'jira', 'linux', 'unix', 'bash', 'testing', 'unit testing', 'jest', 'mocha', 'cypress', 'selenium',
  ];

  // Soft skills
  const softSkills = [
    'leadership', 'communication', 'problem solving', 'teamwork', 'collaboration', 'analytical', 'critical thinking',
  ];

  // Find which keywords appear in the JD
  const foundKeywords = [];

  technicalKeywords.forEach(kw => {
    // Check for word boundaries to avoid partial matches
    const regex = new RegExp(`\\b${kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(text)) {
      // Normalize the keyword for display
      const displayName = kw.charAt(0).toUpperCase() + kw.slice(1);
      if (!foundKeywords.includes(displayName)) {
        foundKeywords.push(displayName);
      }
    }
  });

  softSkills.forEach(kw => {
    if (text.includes(kw.toLowerCase())) {
      const displayName = kw.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
      if (!foundKeywords.includes(displayName)) {
        foundKeywords.push(displayName);
      }
    }
  });

  // Also extract years of experience if mentioned
  const expMatch = text.match(/(\d+)\+?\s*(?:years?|yrs?)(?:\s+of)?\s+(?:experience|exp)/i);
  if (expMatch) {
    foundKeywords.push(`${expMatch[1]}+ Years Experience`);
  }

  console.log('Found keywords in JD:', foundKeywords);
  return foundKeywords.slice(0, 25); // Limit to 25 keywords
}

// Show resume detail view
function showResumeDetail(resumeId) {
  const resume = resumes.find(r => r._id === resumeId);
  const analysis = analysisResults?.find(r => r.resumeId === resumeId);

  if (!resume) return;

  detailTitle.textContent = resume.name;

  if (analysis) {
    const scoreClass = analysis.score >= 80 ? 'high' : analysis.score >= 60 ? 'medium' : 'low';
    detailScoreValue.textContent = analysis.score + '%';
    detailScoreValue.className = 'detail-score-value ' + scoreClass;

    matchedCount.textContent = `(${analysis.matchedKeywords.length})`;
    missingCount.textContent = `(${analysis.missingKeywords.length})`;

    matchedKeywords.innerHTML = analysis.matchedKeywords.map(kw => `
      <div class="keyword-item matched">
        <div class="keyword-icon matched">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
          </svg>
        </div>
        <span class="keyword-text">${kw}</span>
        <span class="keyword-category">Skill</span>
      </div>
    `).join('') || '<p style="color: #64748b; font-size: 12px;">No matched keywords</p>';

    missingKeywords.innerHTML = analysis.missingKeywords.map(kw => `
      <div class="keyword-item missing">
        <div class="keyword-icon missing">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </div>
        <span class="keyword-text">${kw}</span>
        <span class="keyword-category">Skill</span>
      </div>
    `).join('') || '<p style="color: #64748b; font-size: 12px;">No missing keywords - Great match!</p>';
  } else {
    detailScoreValue.textContent = '--';
    detailScoreValue.className = 'detail-score-value';
    matchedCount.textContent = '(0)';
    missingCount.textContent = '(0)';
    matchedKeywords.innerHTML = '<p style="color: #64748b; font-size: 12px;">Extract and analyze a JD first</p>';
    missingKeywords.innerHTML = '';
  }

  detailView.classList.remove('hidden');
}

// Hide detail view
function hideDetailView() {
  detailView.classList.add('hidden');
}

// Show status message
function showStatus(message, type = 'info') {
  statusMessage.textContent = message;
  statusMessage.className = `status ${type}`;
  statusMessage.classList.remove('hidden');

  setTimeout(() => {
    statusMessage.classList.add('hidden');
  }, 3000);
}

// Format file size
function formatFileSize(bytes) {
  if (!bytes) return '0 KB';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// Format date
function formatDate(dateStr) {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// Event Listeners
loginBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: `${APP_URL}/login?extension=true` });
  window.close();
});

logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['accessToken', 'refreshToken', 'user']);
  isAuthenticated = false;
  currentUser = null;
  resumes = [];
  analysisResults = null;
  showAuthSection();
  showStatus('Logged out successfully', 'success');
});

extractJdBtn.addEventListener('click', extractJD);
analyzeBtn.addEventListener('click', analyzeAllResumes);
backBtn.addEventListener('click', hideDetailView);
